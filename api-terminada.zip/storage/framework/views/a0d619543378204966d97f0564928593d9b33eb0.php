<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Pendiente de autorizacion')); ?></div>

                <div class="card-body">
                    

                    <?php echo e(__('Antes de empezar a operar debe ser autorizado por otro administrador.')); ?>

                    
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\www\tano2-copia\resources\views/auth/verify.blade.php ENDPATH**/ ?>