<?php $__env->startSection('content'); ?>
<div>
    <?php if(session('status')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session('status')); ?>

    </div>
    <?php endif; ?>
  <nuevoalbaran-component :numeroaviso="<?php echo e($id); ?>" ></nuevoalbaran-component>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\www\tano2-copia\resources\views/movil/albaran.blade.php ENDPATH**/ ?>