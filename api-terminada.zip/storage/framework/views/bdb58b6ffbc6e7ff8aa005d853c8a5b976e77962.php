<?php echo e($slot); ?>

<?php /**PATH E:\www\tano2-copia\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>