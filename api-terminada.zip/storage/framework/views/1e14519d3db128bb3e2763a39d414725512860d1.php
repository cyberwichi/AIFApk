[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH E:\www\tano2-copia\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>